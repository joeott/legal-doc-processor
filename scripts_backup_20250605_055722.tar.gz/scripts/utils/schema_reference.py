#!/usr/bin/env python3
"""
Authoritative schema reference based on actual database
Generated from information_schema queries
"""

SCHEMA_REFERENCE = {
    'source_documents': {
        'primary_key': 'document_uuid',  # NOT 'uuid'
        'foreign_keys': {
            'project_uuid': 'projects.project_id'  # Note: misnamed column
        },
        'status_columns': [
            'status',
            'textract_job_status',  # NOT 'ocr_status'
            'celery_status'
        ],
        'key_columns': [
            'document_uuid',
            'project_uuid',
            'file_name',  # NOT 'filename'
            's3_key',
            's3_bucket',
            'textract_job_id',
            'textract_job_status'
        ]
    },
    'document_chunks': {
        'primary_key': 'id',
        'foreign_key': 'document_uuid',  # NOT 'source_document_uuid'
        'content_column': 'text_content',  # NOT 'content'
        'key_columns': [
            'id',
            'document_uuid',
            'chunk_index',
            'text_content'
        ]
    },
    'entity_mentions': {
        'primary_key': 'id',
        'foreign_key': 'document_uuid',  # NOT 'source_document_uuid'
        'key_columns': [
            'id',
            'document_uuid',
            'entity_text',
            'entity_type'
        ]
    },
    'canonical_entities': {
        'primary_key': 'id',
        'foreign_key': 'created_from_document_uuid',
        'key_columns': [
            'id',
            'created_from_document_uuid',
            'entity_name',
            'entity_type'
        ]
    },
    'relationship_staging': {
        'primary_key': 'id',
        'foreign_key': 'document_uuid',  # NOT 'source_document_uuid'
        'key_columns': [
            'id',
            'document_uuid',
            'source_entity_id',
            'target_entity_id',
            'relationship_type'
        ]
    },
    'processing_tasks': {
        'primary_key': 'id',
        'foreign_key': 'document_id',  # NOT 'document_uuid'
        'key_columns': [
            'id',
            'celery_task_id',  # NOT 'task_id'
            'document_id',  # NOT 'document_uuid'
            'task_type',
            'status',
            'error_message'
        ]
    }
}

def get_correct_column_name(table, purpose):
    """Get the correct column name for a given purpose"""
    if purpose == 'document_fk':
        # Foreign key to documents table
        if table == 'canonical_entities':
            return 'created_from_document_uuid'
        else:
            return 'document_uuid'
    elif purpose == 'content':
        if table == 'document_chunks':
            return 'text_content'
        else:
            return 'content'
    return None

# Common query patterns with correct column names
QUERY_PATTERNS = {
    'count_chunks': """
        SELECT COUNT(*) FROM document_chunks 
        WHERE document_uuid = :doc_uuid
    """,
    'count_entities': """
        SELECT COUNT(*) FROM entity_mentions 
        WHERE document_uuid = :doc_uuid
    """,
    'count_canonical': """
        SELECT COUNT(*) FROM canonical_entities 
        WHERE created_from_document_uuid = :doc_uuid
    """,
    'count_relationships': """
        SELECT COUNT(*) FROM relationship_staging 
        WHERE document_uuid = :doc_uuid
    """,
    'document_status': """
        SELECT document_uuid, file_name, status, textract_job_status, 
               textract_job_id, s3_key, s3_bucket
        FROM source_documents 
        WHERE document_uuid = :doc_uuid
    """,
    'pipeline_summary': """
        SELECT 
            sd.document_uuid,
            sd.file_name,
            sd.status,
            sd.textract_job_status,
            COUNT(DISTINCT dc.id) as chunk_count,
            COUNT(DISTINCT em.id) as entity_count,
            COUNT(DISTINCT ce.id) as canonical_count,
            COUNT(DISTINCT rs.id) as relationship_count
        FROM source_documents sd
        LEFT JOIN document_chunks dc ON sd.document_uuid = dc.document_uuid
        LEFT JOIN entity_mentions em ON sd.document_uuid = em.document_uuid
        LEFT JOIN canonical_entities ce ON sd.document_uuid = ce.created_from_document_uuid
        LEFT JOIN relationship_staging rs ON sd.document_uuid = rs.document_uuid
        WHERE sd.document_uuid = :doc_uuid
        GROUP BY sd.document_uuid, sd.file_name, sd.status, sd.textract_job_status
    """
}