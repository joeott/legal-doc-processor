#!/usr/bin/env python3
"""Create default project for document processing"""

import os
import sys
import uuid
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from scripts.db import DatabaseManager
from sqlalchemy import text

def create_default_project():
    """Create default project if it doesn't exist"""
    
    db = DatabaseManager(validate_conformance=False)
    session = next(db.get_session())
    
    try:
        # Check if any projects exist
        result = session.execute(text("SELECT COUNT(*) FROM projects"))
        count = result.scalar()
        
        if count == 0:
            # Create default project
            project_uuid = str(uuid.uuid4())
            project_name = "Default Legal Project"
            
            insert_query = text("""
                INSERT INTO projects (
                    id, project_id, name, description, 
                    created_at, updated_at, active
                ) VALUES (
                    1, :project_id, :name, :description,
                    :created_at, :updated_at, true
                )
            """)
            
            session.execute(insert_query, {
                'project_id': project_uuid,
                'name': project_name,
                'description': 'Default project for document processing',
                'created_at': datetime.utcnow(),
                'updated_at': datetime.utcnow()
            })
            
            session.commit()
            print(f"✅ Created default project: {project_name} (UUID: {project_uuid})")
            
            return project_uuid
        else:
            # Get existing project
            result = session.execute(text("SELECT project_id FROM projects WHERE id = 1"))
            existing_uuid = result.scalar()
            print(f"ℹ️  Default project already exists: {existing_uuid}")
            return existing_uuid
            
    except Exception as e:
        session.rollback()
        print(f"❌ Error creating project: {e}")
        raise
    finally:
        session.close()

if __name__ == "__main__":
    project_uuid = create_default_project()
    print(f"\nProject UUID: {project_uuid}")
    print("Update .env with: DEFAULT_PROJECT_UUID=" + str(project_uuid))